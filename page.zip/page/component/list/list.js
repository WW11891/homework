// page/component/list/list.js
Page({
  data: {
    category: '',
    productList: [],
    allProducts: {
      fruit: [
        { id: 5, image: '/image/c2.png', title: '冰糖雪梨', price: 0.01 },
        { id: 6, image: '/image/c4.png', title: '冰糖雪梨', price: 0.01 },
        // 其他果类商品
      ],
      vegetable: [
        { id: 2, image: '/image/s5.png', title: '芹菜', price: 0.02 },
        // 其他蔬菜商品
      ]
    }
  },

  onLoad(options) {
    const category = options.category || 'fruit'; // 获取传递的分类参数，默认是 'fruit'
    this.setData({
      category,
      productList: this.data.allProducts[category] || []
    });
  },

  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})