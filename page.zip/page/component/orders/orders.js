Page({
  data: {
    address: {},
    hasAddress: false,
    total: 0,
    orders: []
  },

  onReady() {
    this.getTotalPrice();
  },
  // 获取传递过来的已选择商品信息
onLoad() {
  let selectedCarts = wx.getStorageSync('selectedCarts') || [];
  this.setData({
      selectedCarts: selectedCarts
  });
  this.getTotalPrice();
},

  
  onShow() {
    const self = this;
    wx.getStorage({
      key: 'address',
      success(res) {
        self.setData({
          address: res.data,
          hasAddress: true
        })
      }
    });
    
    let selectedCarts = wx.getStorageSync('selectedCarts') || [];
    this.setData({
      orders: selectedCarts
    });
    this.getTotalPrice();
  },

  getTotalPrice() {
    let orders = this.data.orders;
    let total = 0;
    for (let i = 0; i < orders.length; i++) {
      total += orders[i].num * orders[i].price;
    }
    this.setData({
      total: total.toFixed(2)
    });
  },

  toPay() {
    wx.showModal({
      title: '提示',
      content: '支付成功',
      text: 'center',
      complete() {
        wx.switchTab({
          url: '/page/component/user/user'
        })
      }
    });
  }
});
