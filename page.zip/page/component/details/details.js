// page/component/details/details.js
 Page({
  data: {
    goods: [{
      id: 1,
      image: '/image/s4.png',
      title: '瓜子',
      price: 0.01,
      stock: '有货',
      detail: '这里是瓜子详情。',
      parameter: '125g/个',
      service: '不支持退货'
    },{
      id: 2,
      image: '/image/s5.png',
      title: '芹菜',
      price: 0.01,
      stock: '有货',
      detail: '这里是芹菜详情。',
      parameter: '125g/个',
      service: '不支持退货'
    },
    {
      id: 3,
      image: '/image/s6.png',
      title: '饼干',
      price: 5.00,
      stock: '有货',
      detail: '这里是饼干详情。',
      parameter: '250g/个',
      service: '不支持退货'
    },
    {
      id: 4,
      image: '/image/c3.png',
      title: '苹果',
      price: 11.99,
      stock: '有货',
      detail: '这里是苹果详情。',
      parameter: '/kg',
      service: '不支持退货'
    },
    {
      id: 5,
      image: '/image/c2.png',
      title: '枸杞',
      price: 0.01,
      stock: '有货',
      detail: '这里是枸杞详情。',
      parameter: '125g/个',
      service: '不支持退货'
    },
    {
      id: 6,
      image: '/image/c4.png',
      title: '枸杞',
      price: 0.01,
      stock: '有货',
      detail: '这里是枸杞详情。',
      parameter: '125g/个',
      service: '不支持退货'
    }],
    num: 1,
    totalNum: 0,
    hasCarts: false,
    curIndex: 0,
    show: false,
    scaleCart: false,
    cartItems: []  // 存储购物车商品
  },

  onLoad: function (options) {  
    let id = options.id;
    let goodsList = this.data.goods;
    let goods = goodsList.find(item => item.id === parseInt(id));
    if (goods) {
      this.setData({ goods });
    } else {
      console.error('没有找到对应的商品 ID:', id);
    }
  },
	onLoad: function(options) {  
	  let id = options.id; // 确保 id 是数字类型  
	  let goods= this.data.goods.find(item => item.id === parseInt(id));  
	  if (goods) {  
	    this.setData({  
	      goods: goods // 只显示一个商品  
	    });  
	  } else {  
	    // 如果没有找到，您可以决定如何处理这种情况，例如显示一个错误消息  
	    console.error('没有找到对应的商品 ID:', goodsId);  
	    // 这里您可能想要设置 goods 为空数组或显示默认商品等  
	  } 
	},
 
  addCount() {
    let num = this.data.num;
    num++;
    this.setData({ num });
  },
   
 addToCart() {
  const self = this;
  const num = this.data.num;
  let total = this.data.totalNum;
  let cartItems = wx.getStorageSync('cartItems') || [];

  let item = {
    id: this.data.goods.id,
    image: this.data.goods.image,
    title: this.data.goods.title,
    price: this.data.goods.price,
    num: num,
    selected: true
  };

  let found = false;
  for (let i = 0; i < cartItems.length; i++) {
    if (cartItems[i].id === item.id) {
      cartItems[i].num += num;
      found = true;
      break;
    }
  }
  if (!found) {
    cartItems.push(item);
  }

  wx.setStorageSync('cartItems', cartItems);
  self.setData({
    show: true,
    cartItems: cartItems
  });
  setTimeout(() => {
    self.setData({ show: false, scaleCart: true });
    setTimeout(() => {
      self.setData({ scaleCart: false, hasCarts: true, totalNum: num + total });
    }, 200);
  }, 300);
},

  bindTap(e) {
    const index = parseInt(e.currentTarget.dataset.index);
    this.setData({
      curIndex: index
    })
  }
 
})
