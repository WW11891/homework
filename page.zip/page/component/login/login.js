Page({
  onLogin: function(event) {
    const { username, password } = event.detail.value;
    const storedUsers = wx.getStorageSync('users') || [];
    const user = storedUsers.find(u => u.username === username && u.password === password);
    if (user) {
      wx.showToast({ title: '登录成功' });
      // 保存用户信息
      wx.setStorageSync('loggedInUser', user);
      // 跳转到主页
      wx.switchTab({ url: '../index/index' });
    } else {
      wx.showToast({ title: '用户名或密码错误', icon: 'none' });
    }
  }
});
