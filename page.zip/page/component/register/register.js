Page({
  onRegister: function(event) {
    const { username, password } = event.detail.value;
    let storedUsers = wx.getStorageSync('users') || [];
    const existingUser = storedUsers.find(u => u.username === username);
    if (existingUser) {
      wx.showToast({ title: '用户名已存在', icon: 'none' });
    } else {
      const newUser = { username, password };
      storedUsers.push(newUser);
      wx.setStorageSync('users', storedUsers);
      wx.showToast({ title: '注册成功' });
      // 使用 setTimeout 延迟跳转
      setTimeout(() => {
        wx.navigateTo({ url: '../login/login' });
      }, 1500); // 延迟 1.5 秒跳转
    }
  }
});
