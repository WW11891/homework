var app=getApp()
Page({
  date:{
   userInfo:{},
   hasUserInfo:false,
   canIUseGetUseProfile:false,
  },
  onLoad(){
    if(wx.getUserProfile){
      this.setData({
        canIUseGetUseProfile:true
      })
    }
  },
  getUserProfile:function(e){
  wx.getUserProfile({
    desc: '获取用户信息',
    success: (res) => {
      this.setData({
        userInfo:res.userInfo,
        hasUserInfo:true
      })
    },
  })
},
changeAvatar:function(){
  const _this=this;
  wx.chooseImage({
    count:1,
    sizeType:['original','compressed'],
    sourceType:['album','camera'],
    success(res){
      const tempFilePath=res.tempFilePaths[0];
      _this.setData({
        personImage:tempFilePath
      })
      wx.uploadFile({
        filePath: 'tempFilePath',
        name: 'file',
        url: 'config.UPLOADFILE',
        formData:{},
        success(res){
          const data=res.data;
          console.log(data);
        }
      })
    }
      })
    },
    phone:function(){
      wx.makePhoneCall({
        phoneNumber: '10086',
      })
    },
    dialog:function(){
      wx.showModal({
        title:'提示',
        content:'客服现在没空！',
        success(res){
          if(res.confirm){
            console.log('用户点击了确定')
          }else if(res.cancel){
            console.log('用户点击了取消')
          }
        }
      })
      },
  })
