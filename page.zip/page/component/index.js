Page({
  data: {
    imgUrls: [
      '/image/bj2.jpg',
      '/image/bj.jpg',
      '/image/bj3.jpg'
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 3000,
    duration: 800,
  }
})